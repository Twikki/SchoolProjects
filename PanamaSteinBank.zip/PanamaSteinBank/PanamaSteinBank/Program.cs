﻿using System;

namespace PanamaSteinBank
{
    class Program
    {
        static void Main()
        {

            // Sætter en velkommen besked uden om loopet
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"

      ___            __               ___         ___                                           
\  / |__  |    |__/ /  \  |\/|  |\/| |__  |\ |     |  | |                                       
 \/  |___ |___ |  \ \__/  |  |  |  | |___ | \|     |  | |___                                    
                                                                                                
 __                                          __      __  ___  ___            __                 
|__)  /\  |\ |  /\   |\/|  /\      /\  |\ | |  \    /__`  |  |__  | |\ |    |__)  /\  |\ | |__/ 
|    /~~\ | \| /~~\  |  | /~~\    /~~\ | \| |__/    .__/  |  |___ | | \|    |__) /~~\ | \| |  \ 
                                                                                                                                                                                            

                ");

            GUI.Main_Menu();

        }
    }
}
