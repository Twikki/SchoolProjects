﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PanamaSteinBank
{
    public class Konti
    {
        // Array til kunde konti
        public static Int64[] KontoNr = new Int64[1000];
        // Array til kunde saldo
        public static double[] Saldo = new double[1000];
        // Array til kunde lån
        public static double[] lån = new double[1000];
        // Array til kunde udlånsrenten
        public static double[] UdlånRente = new double[1000];
        // Array til antal år kunden låner penge i
        public static int[] LånÅr = new int[1000];
        // Array til hvor meget banken tjener på renter
        public static double[] Profit = new double[1000];

      
    }

}
