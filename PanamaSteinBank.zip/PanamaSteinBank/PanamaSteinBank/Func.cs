﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PanamaSteinBank
{
    public class Func
    {
            // Funktion til at generer et Random konto nr
            public static int RandomKontonr()
        {
            // Generer et konto nr til kunden

            Random r = new Random();
            int genRand = r.Next(1000, 9999);
            return genRand;
        }
            
            // Funktion til at oprette en kunde
            public static void OpretKunde()
        {
            Console.Clear();

            // Indtast alder og valider
            Logo_Opret_Kunde();
            Console.WriteLine("\nIndtast Alder: ");
            var ageAsString = Console.ReadLine();
            int alder;
            while (!int.TryParse(ageAsString, out alder))
            {
                Console.WriteLine("Du SKAL indtaste en alder for at forsætte.");
                ageAsString = Console.ReadLine();
                
            }
            int nummer = 0;
            alder = Convert.ToInt32(string.Format(ageAsString));

            //Hvis kunden er under 18 bliver han bedt om at hente mor eller far og går
            if (alder < 18)
            {
                Console.WriteLine("Man skal være 18, for at være kunde i Panama & Stein Bank, hent din mor eller far");
                Console.ReadKey();
            }

            // Hvis alder er lig med 18 eller derover.  Kører denne if statement.
            if (alder >= 18)
            {
                Kunder.Alder[Kunder.ctr] = alder;

                // Opretter automatisk et konto nr til kunden, kalder funktionen RandomKontonr
                Int64 temp = Func.RandomKontonr();
                Int64 NyKontoNr = 7681000719;
                Konti.KontoNr[Kunder.ctr] = Convert.ToInt64(string.Format("{0}{1}", NyKontoNr, temp));


                // Indtast navn og valider (der skal være input)
                Console.WriteLine("Indtast Navn: ");
                string validatename = Console.ReadLine();
                while (string.IsNullOrEmpty(validatename))
                {
                    Console.WriteLine("Du kan ikke indtaste et blankt navn, prøv igen.");
                    validatename = Console.ReadLine();
                }

                Kunder.Navn[Kunder.ctr] = validatename;

                // Indtast CPR og validre (der skal være input)

                Console.WriteLine("Indtast CPR nummer ");
                string validatecpr = Console.ReadLine();
                while (string.IsNullOrEmpty(validatecpr))
                {
                    Console.WriteLine("Du kan ikke indtaste et blankt CPR nummer, prøv igen.");
                    validatecpr = Console.ReadLine();
                }
                Kunder.CPR[Kunder.ctr] = validatecpr;

                // Infomationer om kunden
                Console.WriteLine("Indtast Adresse: ");
                Kunder.Adresse[Kunder.ctr] = (Console.ReadLine());
                Console.WriteLine("Indtast TLF NR: ");
                Kunder.TLF[Kunder.ctr] = (Console.ReadLine());

                // Her skal kunden vælge om han/hun vil insætte penge nu eller tilbage til hovedemenu.
                Console.WriteLine("\n1: indsæt penge på konto\n2: exit til Main Menu");
                Console.Write("Vælg en menu: ");
                nummer = Convert.ToInt32(Console.ReadLine());

                if (nummer == 1)
                {
                    Console.WriteLine("Indtast ønsket beløb");
                    Konti.Saldo[Kunder.ctr] = Convert.ToDouble(Console.ReadLine());
                }

                // Counter der holder styr antal kunder, hver gang der bliver oprettet en kunde, laver den en +1
                Kunder.ctr = Kunder.ctr + 1;

                Console.Clear();
                Func.Logo_Main_Menu();
                GUI.Main_Menu();
            }
        }

            // Funktion til at slette en kunde
            public static void SletKunde()
            {
            // Kontrollere om der er 0 kunder, hvis der er 0 kunder, spring tilbage til main menu
            if (Kunder.ctr == 0)
            {
                Console.Clear();
                Logo_Main_Menu();
                GUI.Main_Menu();
            }

            // Hvis der er over 0 kunder, kør denne else i stedet for.
            else
            {
                Console.Clear();
                Logo_Slet_Kunde();
                
                Console.ForegroundColor = ConsoleColor.DarkGreen;

                // Vi laver en vis alle kunder, så medarbejderen nemmere kan finde CPR nummer, hvis kunden "har glemt sit CPR nummer" :)
                Vis_Alle_Kunder();
                Console.WriteLine("Indtast CPR nummer på kunden:");
                Console.Write("CPR Nummer: ");

                // Finder index nummeret på kunden, ud fra CPR nummeret.
                string CPRtemp = (Console.ReadLine());
                int IndexNr = Array.FindIndex(Kunder.CPR, item => item == CPRtemp);
             
                // Fjerner kunde og flytter elementar i Arrays
                int i = 0;
                for (i = IndexNr; i < Kunder.ctr; i++)
                {
                    // Flytter elementer i Kunder class
                    Kunder.Navn[i] = Kunder.Navn[i + +1];
                    Kunder.CPR[i] = Kunder.CPR[i + 1];
                    Kunder.TLF[i] = Kunder.TLF[i + 1];
                    Kunder.Adresse[i] = Kunder.Adresse[i + 1];
                    Konti.KontoNr[i] = Konti.KontoNr[i + 1];
                    Konti.lån[i] = Konti.lån[i + 1];
                }
                // Fjerner 1 i antal kunder
                Kunder.ctr = Kunder.ctr - 1;

                Console.Clear();
                Logo_Main_Menu();
                GUI.Main_Menu();

            }

            }

            // Funktion til at låne penge til en kunde
            public static void LånPenge()
            {

            // Kontrollere om der er 0 kunder, hvis der er 0 kunder, spring tilbage til main menu
            if (Kunder.ctr == 0)
            {
                Console.Clear();
                Logo_Main_Menu();
                GUI.Main_Menu();
            }

            // Hvis der er over 0 kunder, kør denne else i stedet for.
            else
            {
                // Udlån penge til kunde

                Console.Clear();
                Logo_Konto_Lån();
                for (int i = 0; i < Kunder.ctr; i++)
                {
                    Console.Write("\n");
                    Console.WriteLine("Der er følgende folk der kan tage et lån");
                    Console.Write("Navn: {0}, CPR {1} : \n\n", Kunder.Navn[i], Kunder.CPR[i]);
                    Console.Write("------------------------------------\n");
                }


                Console.WriteLine("Indtast CPR nummer på kunden du ønsker skal låne penge:");
                Console.Write("CPR Nummer: ");

                // Find index nummer på kunde
                string CPRtemp = (Console.ReadLine());
                int IndexNr = Array.FindIndex(Kunder.CPR, item => item == CPRtemp);

                int år;
                double antal, rente, interest, total_amt;

                // Smider ind i lån array
                Console.Write("Hvor Meget vil du låne : ");
                antal = Convert.ToDouble(Console.ReadLine());
                Konti.lån[IndexNr] = Konti.lån[IndexNr] + antal;

                // Smider ind i år array
                Console.Write("Hvor mange år : ");
                år = Convert.ToInt32(Console.ReadLine());
                Konti.LånÅr[IndexNr] = år;

                // smider ind i udlånrente array
                Console.Write("RenteSatsen : ");
                rente = Convert.ToDouble(Console.ReadLine());
                Konti.UdlånRente[IndexNr] = rente;


                // udbytte af renten
                interest = antal * år * rente / 100;
                // pulsser lån med renteudbytte
                total_amt = antal + interest;


                Console.WriteLine("Samlet lån efter {1} år : {0}", total_amt, år);
                Console.ReadLine();

            }

            }

            // Funktion til at indsætte penge på en kundes konto
            public static void IndsætPenge()
            {

            // Kontrollere om der er 0 kunder, hvis der er 0 kunder, spring tilbage til main menu
            if (Kunder.ctr == 0)
            {
                Console.Clear();
                Logo_Main_Menu();
                GUI.Main_Menu();
            }

            // Hvis der er over 0 kunder, kør denne else i stedet for.
            else
            {
                // Indsæt penge
                Console.Clear();
                Logo_Konto_Indsæt();
                Vis_Alle_Kunder();
           
                Console.WriteLine("Indtast CPR nummer på kunden du ønsker skal indsætte penge:");
                Console.Write("CPR Nummer: ");

                // Find index nummer på kunde
                string CPRtemp = (Console.ReadLine());
                int IndexNr = Array.FindIndex(Kunder.CPR, item => item == CPRtemp);

                // Smider beløb ind på kundens konto
                Console.WriteLine("hvor mange penge skal kunden indsætte? Indtast i heltal");
                Konti.Saldo[IndexNr] = Konti.Saldo[IndexNr] + Convert.ToDouble(Console.ReadLine());
            }

            }

            // Funktion til at trække penge fra en kundes konto
            public static void TrækPenge()
            {

            // Kontrollere om der er 0 kunder, hvis der er 0 kunder, spring tilbage til main menu
            if (Kunder.ctr == 0)
            {
                Console.Clear();
                Logo_Main_Menu();
                GUI.Main_Menu();
            }

            // Hvis der er over 0 kunder, kør denne else i stedet for.
            else
            {
                // Træk penge
                Console.Clear();
                Logo_Konto_Træk();
                Vis_Alle_Kunder();
               

                Console.WriteLine("Indtast CPR nummer på kunden du ønsker fratrække penge:");
                Console.Write("CPR Nummer: ");

                // Find index nummer på kunde
                string CPRtemp = (Console.ReadLine());
                int IndexNr = Array.FindIndex(Kunder.CPR, item => item == CPRtemp);

                Console.WriteLine("hvor mange penge skal der trækkes? Indtast i heltal");
                Konti.Saldo[IndexNr] = Konti.Saldo[IndexNr] - Convert.ToInt64(Console.ReadLine());
                }
            }

            // Funktion til at vise bankens samlet kapital ( Kundernes indestående i banken )
            public static void SamletKapital()
            {
            // Beregn bankens samlet kapital

            Console.Clear();

            // Beregn bankens kapital
            double Kapitalsum = 0;
                for (int i = 0; i < Kunder.ctr; i++)
                {
                    Kapitalsum += Konti.Saldo[i];
                }

                //Beregn bankens udlån rente fortjeneste

                for (int i = 0; i < Kunder.ctr; i++)
                {

                    double BankUdlån = 0;
                    double Lånår = 0;
                    double Udlånrente = 0;
                    BankUdlån = Konti.lån[i];
                    Lånår = Konti.LånÅr[i];
                    Udlånrente = Konti.UdlånRente[i];
                    Konti.Profit[i] = BankUdlån * Lånår * Udlånrente / 100;

                }

                double Profit = 0;
                for (int i = 0; i < Kunder.ctr; i++)
                {
                    Profit += Konti.Profit[i];
                }

                // Beregn bankens udlån
                double udlån = 0;
                for (int i = 0; i < Kunder.ctr; i++)
                {
                    udlån += Konti.lån[i];
                }

                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write(@"
            #####################################################################
            #                                                                   #
            #               Panama and Stein Bank samlet kapital                #
            #                                                                   #
            #####################################################################
            ");
                Console.ResetColor();

                Console.WriteLine("\nBankens samlet Kapital er: {0} Dkk", Kapitalsum);
                Console.WriteLine("\nBankens samlet Udlån er: {0} Dkk", udlån);
                Console.WriteLine("\nBankens samlede Profit på Udlån er: {0} Dkk", Profit);
                Console.WriteLine("\n------------------------------------");

        }

            // Funktion til at vise alle kunder, og kort info
            public static void Vis_Alle_Kunder()
            {
           
           
                // Viser alle kunder i banken, i vores for loop.
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write("\n\nDer er følgende kunder:\n");
                Console.ResetColor();

                for (int i = 0; i < Kunder.ctr; i++)
                {
                    Console.Write("\n");
                    Console.Write("Navn: {0}, {1} år - CPR: {2} - Konto Nr: {3} - Saldo: {4} Dkk - Lån: {5}\n\n", Kunder.Navn[i], Kunder.Alder[i], Kunder.CPR[i], Konti.KontoNr[i], Konti.Saldo[i], Konti.lån[i]);
                    Console.Write("--------------------------------------------\n");
                }
            }

            // Funktion til at vise en specifik kunde og alle detajler omkring kunden
            public static void Vis_En_Kunde()
            {
            // Vis specifik kunde

            Console.Clear();
            Logo_Vis_Kunde();

            // Kontrollere om der er 0 kunder, hvis der er 0 kunder, spring tilbage til main menu
            if (Kunder.ctr == 0)
            {
                Console.Clear();
                Logo_Main_Menu();
                GUI.Main_Menu();
            }

            // Hvis der er over 0 kunder, kør denne else i stedet for.
            else
            {
            for (int i = 0; i < Kunder.ctr; i++)
            {
                Console.Write("\n");
                Console.WriteLine("Der er følgende folk at søge på");                                   
                Console.Write("Navn: {0}, CPR {1} : \n\n", Kunder.Navn[i], Kunder.CPR[i]);
                Console.Write("------------------------------------\n");
            }
                Console.WriteLine("\nIndtast CPR nummer på kunden du ønsker at søge på:");
                Console.WriteLine("------------------------------------");                                                              
                Console.Write("CPR Nummer: ");

                // Find index nummer på kunde
                string CPRtemp = (Console.ReadLine());
                int IndexNr = Array.FindIndex(Kunder.CPR, item => item == CPRtemp);

                // Kunde information
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("### Kunde information ###");
                Console.ResetColor();
                Console.WriteLine(" ");

                Console.WriteLine("Navn: {0}", Kunder.Navn[IndexNr]);
                Console.WriteLine("CPR Nummer: {0}", Kunder.CPR[IndexNr]);
                Console.WriteLine("Alder: {0}", Kunder.Alder[IndexNr]);
                Console.WriteLine("Adresse: {0}", Kunder.Adresse[IndexNr]);
                Console.WriteLine("Telefon Nummer: {0}", Kunder.TLF[IndexNr]);
                Console.WriteLine("");

                // Konti information
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("### Konti information ###");
                Console.ResetColor();
                Console.WriteLine(" ");

                Console.WriteLine("Saldo: {0} Dkk", Konti.Saldo[IndexNr]);
                Console.WriteLine("Konto Nummer: {0}", Konti.KontoNr[IndexNr]);
                Console.WriteLine("Lån i banken: {0} Dkk", Konti.lån[IndexNr]);
                Console.WriteLine("Rentesats: {0} %", Konti.UdlånRente[IndexNr]);
                Console.WriteLine("Låneår: {0} år", Konti.LånÅr[IndexNr]);
                Console.ReadKey();
                Console.Clear();
            }

        }

            // Funktion til at vise bankens logo
            public static void Logo()
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                                                                   #
            #####################################################################
            ");
                Console.ResetColor();
            }

            public static void Logo_Opret_Kunde()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             Opret Kunde                           #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

            public static void Logo_Slet_Kunde()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             Slet Kunde                            #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

            public static void Logo_Konto_Lån()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             Konto Lån                             #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

            public static void Logo_Konto_Indsæt()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             Konto Indsæt                          #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

            public static void Logo_Konto_Træk()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                           Konto Træk Penge                        #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

        // Funktion til at vise bankens logo main Menu
            public static void Logo_Main_Menu()
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             MAIN MENU                             #
            #                                                                   #
            #####################################################################
            ");
                Console.ResetColor();
            }

            // Funktion til at vise kunde logo
            public static void Logo_Vis_Kunde()
            {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                            Vis Kunde Menu                         #
            #                                                                   #
            #####################################################################
            ");
                Console.ResetColor();
            }

            // Funktion til at vise konto logo
            public static void Logo_Konto_Menu()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             Konto Menu                            #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

            // Funktion til at vise logo kunde menu
            public static void Logo_Kunde_Menu()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(@"
            #####################################################################
            #                                                                   #
            #                        Panama and Stein Bank                      #
            #                             Kunde Menu                            #
            #                                                                   #
            #####################################################################
            ");
            Console.ResetColor();
        }

            // Funktion til kunde menu
            public static void KundeMenu()
            {
                // Kunde Menu
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Logo_Kunde_Menu();
                Console.ResetColor();
                Console.WriteLine("\n\n1: Opret Kunde\n2: Slet Kunde\n3: Main Menu");
                Console.WriteLine("------------------------------------");
                Console.Write("Vælg en menu: ");
                int nummer = Convert.ToInt32(Console.ReadLine());

                while (nummer != 3)
                {

                    if (nummer == 1)
                    {
                        // Kalder funktionen opret kunde
                        Func.OpretKunde();
                    }
                    if (nummer == 2)
                    {
                        // Kalder funktionen Slet kunde
                        Func.SletKunde();
                    }
                    if (nummer == 3)
                    {
                   
                    }

                }

            }
        
    }
}
