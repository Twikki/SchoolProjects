﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PanamaSteinBank
{
    class Kunder
    {

        // Holder styr på antal kunder
        public static int ctr;
        // Array til kunde navne
        public static string[] Navn = new string[1000];
        // Array til kunde alder
        public static int[] Alder = new int[1000];
        // Array til kunde CPR numre
        public static string[] CPR = new string[1000];
        // Array til kunde adresser
        public static string[] Adresse = new string[1000];
        // Array til kunde telefon numre
        public static string[] TLF = new string[1000];
    }
}
