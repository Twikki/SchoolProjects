﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PanamaSteinBank
{
    class GUI
    {
        public static void Main_Menu()
        {

            int nummer;
            Console.ResetColor();
            Console.WriteLine("\n1: Kunder\n2: Konto\n3: Vis kunder\n4: Samlet Bank Kapital\n5: Exit Bank");
            Console.WriteLine("------------------------------------");
            Console.Write("Vælg en menu: ");
            nummer = Convert.ToInt32(Console.ReadLine());

            while (nummer != 5)
            {
                // KundeMenu
                if (nummer == 1)
                {
                    Func.KundeMenu();
                    Console.Clear();
                    Func.Logo_Main_Menu();
                    GUI.Main_Menu();

                    nummer = Convert.ToInt32(Console.ReadLine());
                }

                //Til Indsæt - Træk - lån
                if (nummer == 2)
                {
                    Console.Clear();
                    Func.Logo_Konto_Menu();
                    Console.WriteLine("\n1: Indsæt penge \n2: Træk penge \n3: Lån\n4: Main Menu");
                    Console.WriteLine("Vælg en menu: ");
                    Console.WriteLine("------------------------------------");
                    nummer = Convert.ToInt32(Console.ReadLine());
                    if ( nummer == 1)
                    {
                        Func.Logo();
                        Func.IndsætPenge();
                        Console.Clear();
                        Func.Logo_Main_Menu();
                        Main_Menu();
                    }

                    if (nummer == 2)
                    {
                        Func.TrækPenge();
                        Console.Clear();
                        Func.Logo_Main_Menu();
                        Main_Menu();
                    }

                    if (nummer == 3)
                    {
                        Func.LånPenge();
                        Console.Clear();
                        Func.Logo_Main_Menu();
                        Main_Menu();
                    }

                    if (nummer >= 4)
                    {
                        Console.Clear();
                        Func.Logo_Main_Menu();
                        Main_Menu();
                    }
                  
                }

                //Viser Kunde INFO
                if (nummer == 3)
                {
                    Console.Clear();
                    Func.Logo_Vis_Kunde();
                    Console.ResetColor();
                    Console.Write("\n");
                    Console.WriteLine("1: Vis alle Kunder\n2: Vis en Kunde\n3: Main Menu:");
                    Console.WriteLine("------------------------------------");
                    Console.Write("Vælg en menu: ");
                    nummer = Convert.ToInt32(Console.ReadLine());
                    if (nummer == 1)
                    {
                        Console.Clear();
                        Func.Logo();
                        Func.Vis_Alle_Kunder();
                        GUI.Main_Menu();
                        
                    }
                    if(nummer == 2)
                    {
                        Console.Clear();
                        Func.Logo();
                        Func.Vis_En_Kunde();
                        Func.Logo_Main_Menu();
                        GUI.Main_Menu();
                       
                    }
                    if(nummer >=3 )
                    {
                        Console.Clear();
                        Func.Logo_Main_Menu();
                        GUI.Main_Menu();
                        
                    }
                
                }

                //Viser SamletKapital
                if (nummer == 4)
                {
                    Func.SamletKapital();
                    GUI.Main_Menu();
                    
                }

                if (nummer == 5)
                {
                    break;
                }
            }                                                                                                                                                                                                                                                                                                 
        }
    }
}
